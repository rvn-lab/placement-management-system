# placement-management-system
Placement Management System manages student information in the college with regard to placement. It improves existing system . It has the facility of maintaining the details of the student, thereby reducing the manual work. It will save time and energy which are spending in making reports and collecting data.
